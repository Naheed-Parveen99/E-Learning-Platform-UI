function updateProgress() {
      let progressBar = document.getElementById('progress-bar');
      progressBar.value = 100;
      alert("Course marked as completed!");
  }